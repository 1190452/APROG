/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhopratico;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Massas
 */
public class TrabalhoPratico {

    static final String FILE1 = "PracticalWork.csv";
    static final int Max_EQUIPAS = 50;
    static final int Colunas_arrINTS = 9;
    static final int Colunas_arrNOMES = 2;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner ler = new Scanner(System.in);
        String[][] arrNomesEQUIPAS = new String[Max_EQUIPAS][Colunas_arrNOMES];
        int[][] arrDadosEQUIPAS = new int[Max_EQUIPAS][Colunas_arrINTS];
        int qtd = 0;
        int qtdequipas = 0;
        int numEquipasFinais = 0;
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|      Exercício      |                              Enunciado                                 |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          1          | Leitura do Ficheiro                                                    |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          2          | Inserir Selecoes                                                       |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          3          | Calcular pontos de cada equipa                                         |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          4          | Ordenacao da classificacao                                             |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          5          | Listar a classificação das equipas por grupo                           |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          6          | Listar a classificação das equipas com maior numero de golos marcados  |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          7          | Listar as equipas com um determinado número de golos sofridos          |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          8          | Listar equipas com mais golos sofridos que golos marcados              |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          9          | Listar o primeiro classificado de cada grupo                           |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          10         | Listar informação completa de uma equipa                               |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          11         | Criar um ficheiro com estatisticas de jogos                            |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          12         | Remover equipas que nao passaram a fase de grupos                      |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          13         | Criar um ficheiro com as equipas que vao disputar a fase final         |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          14         | Criar um ficheiro com os jogos da fase seguinte                        |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          0          | Sair                                                                   |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println();
        System.out.println("Introduza o número do exercício");
        int n = ler.nextInt();
        while (n != 0) {
            switch (n) {
                case 1:
                    System.out.println("Ler a informação disponível no ficheiro de texto (PracticalWork.csv) e armazená-la em memória");
                    qtd = lerDADOS(arrNomesEQUIPAS, arrDadosEQUIPAS, FILE1);
                    System.out.println("(INFORMAÇÃO LIDA COM SUCESSO!)");
                    break;
                case 2:
                    System.out.println("Inserir manualmente informação de uma seleção. Não permitir equipas com o mesmo nome.");
                    qtdequipas = inserirEquipa(qtd, arrNomesEQUIPAS, arrDadosEQUIPAS, FILE1);
                    break;
                case 3:
                    System.out.println("Calcular e armazenar em memória a pontuação de todas as equipas.");
                    calcularPontuacao(arrDadosEQUIPAS, qtdequipas);
                    System.out.println("(PONTUAÇÃO CALCULADA COM SUCESSO!)");
                    break;
                case 4:
                    System.out.println("Calcular e armazenar em memória a classificação de todas as equipas nos respetivos grupos.");
                    organizarArrays(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    System.out.println("(CLASSIFICAÇÃO ARMAZENADA COM SUCESSO!)");
                    break;
                case 5:
                    System.out.println("Listar a classificação das equipas por grupo.");
                    listarEquipas(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 6:
                    System.out.println("Listar as equipas cujos golos marcados é igual ao máximo de golos marcados.");
                    listarGolos(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 7:
                    System.out.println("Listar as equipas com um determinado número de golos sofridos (definido pelo utilizador).");
                    listarSofridos(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 8:
                    System.out.println("Listar as equipas que têm mais golos sofridos do que golos marcados, ordenadas alfabeticamente;");
                    listarDiferença(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 9:
                    System.out.println("Listar o primeiro classificado de cada grupo.");
                    listarPrimClass(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 10:
                    System.out.println("Listar informação completa de uma equipa (definida pelo utilizador).");
                    listarInformacao(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    break;
                case 11:
                    System.out.println("Criar um ficheiro de texto (Statistics.txt) com estatísticas dos jogos.");
                    guardarEmFicheiro(arrDadosEQUIPAS, qtdequipas);
                    System.out.println("(FICHEIRO CRIADO COM SUCESSO!)");
                    break;
                case 12:
                    System.out.println("Remover da memória as equipas que não vão disputar a fase seguinte (3º e 4º classificados de cada grupo).");
                    numEquipasFinais = removerSelecao(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
                    System.out.println("(EQUIPAS REMOVIDAS COM SUCESSO!)");
                    break;
                case 13:
                    System.out.println("Criar um ficheiro de texto (FinalStage.csv) com as equipas que vão disputar a fase seguinte do campeonato.");
                    equipasFaseFinal(arrNomesEQUIPAS, arrDadosEQUIPAS, numEquipasFinais);
                    System.out.println("(FICHEIRO CRIADO COM SUCESSO!)");
                    break;
                case 14:
                    System.out.println("Criar um ficheiro de texto (FinalStageGames.txt) com os jogos da fase final.");
                    calendarioJogosFinal(arrNomesEQUIPAS, arrDadosEQUIPAS, numEquipasFinais);
                    System.out.println("(FICHEIRO CRIADO COM SUCESSO!)");
                    break;
                default:
                    break;
            }
            System.out.println();
            System.out.println("Introduza o próximo exercício");
            n = ler.nextInt();
            System.out.println();
        }
    }
///Exercício 1 ------------------------------------------------------------------------

    public static int lerDADOS(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, String FILE1) throws
            FileNotFoundException {

        Scanner lerFicheiro = new Scanner(new File(FILE1));
        int quantidadeLinhas = 0;
        String linha = lerFicheiro.nextLine();
        while (lerFicheiro.hasNextLine()) {
            String line = lerFicheiro.nextLine();
            String[] itens = line.split(",");
            arrNomesEQUIPAS[quantidadeLinhas][0] = itens[0];
            arrNomesEQUIPAS[quantidadeLinhas][1] = itens[1];
            for (int equipa = 0, item = 2; item < itens.length; equipa++, item++) {
                arrDadosEQUIPAS[quantidadeLinhas][equipa] = Integer.parseInt(itens[item]);
            }
            quantidadeLinhas++;
        }
        lerFicheiro.close();
        return quantidadeLinhas;
    }
//Exercício 2 -------------------------------------------------------------------------

    public static int inserirEquipa(int qtd, String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, String FILE1) {
        Scanner lerSelecao = new Scanner(System.in);
        System.out.println("Introduza o Grupo: ");
        arrNomesEQUIPAS[qtd][0] = lerSelecao.next();
        System.out.println("Introduza a Seleção: ");
        String selecao = lerSelecao.next();
        boolean ver = validacao(arrNomesEQUIPAS, qtd, selecao);
        // Ver o numero de colunas que o utilizador introduz
        if (ver == true) {
            arrNomesEQUIPAS[qtd][1] = selecao;
            for (int item = 0; item < 6; item++) {
                arrDadosEQUIPAS[qtd][item] = lerSelecao.nextInt();
            }
            qtd = qtd + 1;
        }
        System.out.println("");
        return qtd;
    }

    public static boolean validacao(String[][] arrNomesEQUIPAS, int qtd, String selecao) {
        for (int l = 0; l < qtd; l++) {
            if (selecao.equalsIgnoreCase(arrNomesEQUIPAS[l][1])) {
                return false;
            }
        }
        return true;
    }
//Exercício 3 -------------------------------------------------------------------------

    public static void calcularPontuacao(int[][] arrDadosEQUIPAS, int qtdequipas) {
        for (int p = 0; p < qtdequipas; p++) {
            arrDadosEQUIPAS[p][6] = arrDadosEQUIPAS[p][1] * 3 + arrDadosEQUIPAS[p][2];
        }
    }
//Exercício 4 -------------------------------------------------------------------------

    public static void organizarArrays(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        ordernarPorPontos(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
    }

    public static void ordernarPorPontos(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        for (int k = 0; k < qtdequipas - 1; k++) {
            for (int j = k + 1; j < qtdequipas; j++) {
                if (arrNomesEQUIPAS[k][0].compareTo(arrNomesEQUIPAS[j][0]) > 0) {
                    fazerTrocas(arrNomesEQUIPAS, arrDadosEQUIPAS, k, j);
                } else {
                    if (arrNomesEQUIPAS[k][0].compareTo(arrNomesEQUIPAS[j][0]) == 0) {
                        if (arrDadosEQUIPAS[j][6] > arrDadosEQUIPAS[k][6]) {
                            fazerTrocas(arrNomesEQUIPAS, arrDadosEQUIPAS, k, j);
                        } else {
                            if (arrDadosEQUIPAS[j][6] == arrDadosEQUIPAS[k][6]) {
                                if (arrDadosEQUIPAS[j][4] > arrDadosEQUIPAS[k][4]) {
                                    fazerTrocas(arrNomesEQUIPAS, arrDadosEQUIPAS, k, j);
                                } else {
                                    if (arrDadosEQUIPAS[j][4] == arrDadosEQUIPAS[k][4]) {
                                        if (arrDadosEQUIPAS[j][5] < arrDadosEQUIPAS[k][5]) {
                                            fazerTrocas(arrNomesEQUIPAS, arrDadosEQUIPAS, k, j);
                                        }
                                    } else {
                                        if (arrDadosEQUIPAS[k][5] == arrDadosEQUIPAS[j][5]) {
                                            if (arrNomesEQUIPAS[k][1].compareTo(arrNomesEQUIPAS[j][1]) > 0) {
                                                fazerTrocas(arrNomesEQUIPAS, arrDadosEQUIPAS, k, j);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void fazerTrocas(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int k, int j) {
        for (int p = 0; p < Colunas_arrNOMES; p++) {
            String auxiliar = arrNomesEQUIPAS[j][p];
            arrNomesEQUIPAS[j][p] = arrNomesEQUIPAS[k][p];
            arrNomesEQUIPAS[k][p] = auxiliar;
        }
        for (int f = 0; f < Colunas_arrINTS; f++) {
            int auxiliar = arrDadosEQUIPAS[j][f];
            arrDadosEQUIPAS[j][f] = arrDadosEQUIPAS[k][f];
            arrDadosEQUIPAS[k][f] = auxiliar;
        }
    }
//Exercício 5 -------------------------------------------------------------------------

    public static void listarEquipas(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        int pos = 1;
        for (int posicao = 0; posicao < qtdequipas; posicao++) {
            if (arrNomesEQUIPAS[posicao][0].equals(arrNomesEQUIPAS[posicao + 1][0])) {
                arrDadosEQUIPAS[posicao][7] = pos;
                pos++;
            } else {
                arrDadosEQUIPAS[posicao][7] = pos;
                pos = 1;
            }
        }
        ImprimirFormat(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas);
    }
//Exercício 6 -------------------------------------------------------------------------

    public static void listarGolos(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        int maxNumGolos = 0;
        for (int i = 0; i < qtdequipas; i++) {
            if (arrDadosEQUIPAS[i][4] > maxNumGolos) {
                maxNumGolos = arrDadosEQUIPAS[i][4];
            }
        }
        System.out.printf("| Grp | Pos |");
        System.out.printf("%-17s", "Equipa");
        System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 0; i < qtdequipas; i++) {
            if (arrDadosEQUIPAS[i][4] == maxNumGolos) {
                System.out.printf("|%-5s|", arrNomesEQUIPAS[i][0]);
                System.out.printf("%5s|", arrDadosEQUIPAS[i][7]);
                System.out.printf("%-17s|", arrNomesEQUIPAS[i][1]);
                System.out.printf("%4s|", arrDadosEQUIPAS[i][6]);
                for (int p = 0; p < 6; p++) {
                    System.out.printf("%4d|", arrDadosEQUIPAS[i][p]);
                }
                System.out.printf("%4d|", (arrDadosEQUIPAS[i][4] - arrDadosEQUIPAS[i][5]));
                System.out.println("");
            }
        }
    }
//Exercício 7 -------------------------------------------------------------------------

    public static void listarSofridos(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        Scanner ler = new Scanner(System.in);
        System.out.println("Introduza o número de golos sofridos: ");
        int NumIntroduzidoUtilizador;
        NumIntroduzidoUtilizador = ler.nextInt();
        
        System.out.println();
        System.out.printf("| Grp | Pos |");
        System.out.printf("%-17s", "Equipa");
        System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 0; i < qtdequipas; i++) {
            if(arrDadosEQUIPAS[i][5] == NumIntroduzidoUtilizador){
            System.out.printf("|%-5s|", arrNomesEQUIPAS[i][0]);
            System.out.printf("%5s|", arrDadosEQUIPAS[i][7]);
            System.out.printf("%-17s|", arrNomesEQUIPAS[i][1]);
            System.out.printf("%4s|", arrDadosEQUIPAS[i][6]);
            for (int p = 0; p < 6; p++) {
                System.out.printf("%4d|", arrDadosEQUIPAS[i][p]);
            }
            System.out.printf("%4d|", Math.abs(arrDadosEQUIPAS[i][5] - arrDadosEQUIPAS[i][4]));
            System.out.println("");
        }
        }
    }
//Exercício 8 -------------------------------------------------------------------------

    public static void listarDiferença(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        int p = 0;
        int numequipas = 0;
        String[][] arrEquipas = new String[40][40];
        int[][] arrStats = new int[40][40];
        for (int i = 0; i < qtdequipas; i++) {
            if (arrDadosEQUIPAS[i][5] > arrDadosEQUIPAS[i][4]) {
                int diferenca = arrDadosEQUIPAS[i][4] - arrDadosEQUIPAS[i][5];
                numequipas = numequipas + 1;
                arrEquipas[p][0] = arrNomesEQUIPAS[i][0];
                arrEquipas[p][1] = arrNomesEQUIPAS[i][1];
                for (int h = 0; h < 8; h++) {
                    arrStats[p][h] = arrDadosEQUIPAS[i][h];
                }
                arrStats[p][8] = diferenca;
                p++;
                diferenca = 0;
            }
        }
        OrganizarAlfabeticamente(arrEquipas, arrStats, numequipas);
       System.out.println("As Equipas com mais golos sofridos do que marcados são: ");
        System.out.println();
        System.out.printf("| Grp | Pos |");
        System.out.printf("%-17s", "Equipa");
        System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int n = 0; n < numequipas; n++) {
            System.out.printf("|%-5s|", arrEquipas[n][0]);
            System.out.printf("%5s|", arrStats[n][7]);
            System.out.printf("%-17s|", arrEquipas[n][1]);
            System.out.printf("%4d|", arrStats[n][6]);
            for (int prox = 0; prox < 6; prox++) {
                    System.out.printf("%4d|", arrStats[n][prox]);
                }  
            System.out.printf("%4d|", Math.abs(arrStats[n][8]));
            System.out.println();
        }
    }

    public static void OrganizarAlfabeticamente(String[][] arrEquipas, int[][] arrStats, int numequipas) {
        for (int l = 1; l < numequipas; l++) {
            for (int i = 0; i < numequipas - 1; i++) {
                int grupo = arrEquipas[i][1].compareTo(arrEquipas[l][1]);
                if (grupo > 0) {
                    String auxiliar = arrEquipas[i][0];
                    arrEquipas[i][0] = arrEquipas[l][0];
                    arrEquipas[l][0] = auxiliar;
                    String Selecao = arrEquipas[i][1];
                    arrEquipas[i][1] = arrEquipas[l][1];
                    arrEquipas[l][1] = Selecao;
                    for (int m = 0; m < Colunas_arrINTS; m++) {
                        int copiastats = arrStats[i][m];
                        arrStats[i][m] = arrStats[l][m];
                        arrStats[l][m] = copiastats;
                    }
                }
            }
        }
    }
//Exercício 9 -------------------------------------------------------------------------

    public static void listarPrimClass(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        System.out.printf("| Grp | Pos |");
                System.out.printf("%-17s", "Equipa");
                System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int posicao = 0; posicao < qtdequipas; posicao++) {
            if (arrDadosEQUIPAS[posicao][7] == 1) {
                System.out.printf("|%-5s|", arrNomesEQUIPAS[posicao][0]);
                System.out.printf("%5s|", arrDadosEQUIPAS[posicao][7]);
                System.out.printf("%-17s|", arrNomesEQUIPAS[posicao][1]);
                System.out.printf("%4d|", arrDadosEQUIPAS[posicao][6]);
                for (int p = 0; p < 6; p++) {
                    System.out.printf("%4d|", arrDadosEQUIPAS[posicao][p]);
                }
                System.out.printf("%4d|", (arrDadosEQUIPAS[posicao][4] - arrDadosEQUIPAS[posicao][5]));
                System.out.println();
            }
        }
    }
//Exercício 10 ------------------------------------------------------------------------- 

    public static void listarInformacao(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        Scanner ler = new Scanner(System.in);
        String selecaoUtilizador;
        System.out.println("Introduza o nome da Seleção: ");
        selecaoUtilizador = ler.next();
        System.out.println();
        System.out.printf("| Grp | Pos |");
                System.out.printf("%-17s", "Equipa");
                System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
                System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");

        for (int linha = 0; linha < qtdequipas; linha++) {
                
            if (arrNomesEQUIPAS[linha][1].equalsIgnoreCase(selecaoUtilizador)) {
                System.out.printf("|%-5s|", arrNomesEQUIPAS[linha][0]);
                System.out.printf("%5s|", arrDadosEQUIPAS[linha][7]);
                System.out.printf("%-17s|", arrNomesEQUIPAS[linha][1]);
                System.out.printf("%4d|", arrDadosEQUIPAS[linha][6]);
                for (int p = 0; p < 6; p++) {
                    System.out.printf("%4d|", arrDadosEQUIPAS[linha][p]);
                }
                System.out.printf("%4d|", Math.abs(arrDadosEQUIPAS[linha][4] - arrDadosEQUIPAS[linha][5]));
                System.out.println();
                System.out.println();
            }

            }
        }
    
//Exercício 11 -------------------------------------------------------------------------

    public static void guardarEmFicheiro(int[][] arrDadosEQUIPAS, int qtdequipas) throws FileNotFoundException {
        int numJogos = totaldeJogos(arrDadosEQUIPAS, qtdequipas);
        int numVitorias = totaldeVitorias(arrDadosEQUIPAS, qtdequipas);
        int numEmpates = totaldeEmpates(arrDadosEQUIPAS, qtdequipas);
        int numDerrotas = totaldeDerrotas(arrDadosEQUIPAS, qtdequipas);
        int numGolosMarc = totalGolosMarc(arrDadosEQUIPAS, qtdequipas);
        int numGolosSofr = totalGolosSofr(arrDadosEQUIPAS, qtdequipas);
        double mediaGolosMarc = mediaGolosMarc(numGolosMarc, numJogos);
        double mediaGolosSofr = mediaGolosSofr(numGolosSofr, numJogos);
        PrintWriter out = new PrintWriter(new File("Statistics.txt"));
        out.println("Total de jogos=" + numJogos);
        out.println("Total de vitórias=" + numVitorias);
        out.println("Total de empates=" + numEmpates);
        out.println("Total de derrotas=" + numDerrotas);
        out.println("Total de golos marcados=" + numGolosMarc);
        out.println("Total de golos sofridos=" + numGolosSofr);
        out.printf("Média de golos marcados por jogo=%.1f%n", mediaGolosMarc);
        out.printf("Média de golos sofridos por jogo=%.1f%n", mediaGolosSofr);
        out.close();
    }

    public static int totaldeJogos(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][0];
        }
        return (total / 2);
    }

    public static int totaldeVitorias(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][1];
        }
        return total;
    }

    public static int totaldeEmpates(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][2];
        }
        return total;
    }

    public static int totaldeDerrotas(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][3];
        }
        return total;
    }

    public static int totalGolosMarc(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][4];
        }
        return total;
    }

    public static int totalGolosSofr(int[][] arrDadosEQUIPAS, int qtdequipas) {
        int total = 0;
        for (int i = 0; i < qtdequipas; i++) {
            total = total + arrDadosEQUIPAS[i][5];
        }
        return total;
    }

    public static double mediaGolosMarc(int numGolosMarc, int numJogos) {
        double total = 0;
        total = (double) numGolosMarc / (double) numJogos;
        return total;
    }

    public static double mediaGolosSofr(int numGolosSofr, int numJogos) {
        double total = 0;
        total = (double) numGolosSofr / (double) numJogos;
        return total;
    }

    //Exercício 12 -------------------------------------------------------------------------
    public static int removerSelecao(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        for (int n = 0; n < qtdequipas; n++) {
           if(arrDadosEQUIPAS[n][7] > 2 ) {
                qtdequipas = retirarSelecao(arrNomesEQUIPAS, arrDadosEQUIPAS, qtdequipas, n);
                n--;
                
            }
        }
        return qtdequipas;
    }

    public static int retirarSelecao(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas, int n) {

        
        for (int p = n; p < qtdequipas - 1; p++) {
            for (int t = 0; t < 2; t++) {
                arrNomesEQUIPAS[p][t] = arrNomesEQUIPAS[p + 1][t];
            }
            for (int x = 0; x < 8; x++) {
                arrDadosEQUIPAS[p][x] = arrDadosEQUIPAS[p + 1][x];
            }
        }
       qtdequipas--;
       return qtdequipas;
    }

    //Exercício 13 -------------------------------------------------------------------------
    public static void equipasFaseFinal(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int numEquipasFinais) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File("FinalStage.csv"));
        for (int i = 0; i < numEquipasFinais; i++) {
            out.print("Grupo" + arrNomesEQUIPAS[i][0] + "," + arrDadosEQUIPAS[i][7] + "º" + "," + arrNomesEQUIPAS[i][1] + "," + arrDadosEQUIPAS[i][6]);
            out.println();
        }
        out.close();
    }

    //Exercício 14 -------------------------------------------------------------------------    
    public static void calendarioJogosFinal(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int numEquipasFinais) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(new File("FinalStageGames.txt"));
        int grupo = 0;
        while (grupo < numEquipasFinais && arrNomesEQUIPAS[grupo][1] != null) {
            out.println("Grupo" + arrNomesEQUIPAS[grupo][0] + arrDadosEQUIPAS[grupo][7] + "º" + arrNomesEQUIPAS[grupo][1] + "-" + "Grupo" + arrNomesEQUIPAS[grupo + 3][0] + arrDadosEQUIPAS[grupo + 3][7] + "º" + arrNomesEQUIPAS[grupo + 3][1]);
            out.println("Grupo" + arrNomesEQUIPAS[grupo + 1][0] + arrDadosEQUIPAS[grupo + 1][7] + "º" + arrNomesEQUIPAS[grupo + 1][1] + "-" + "Grupo" + arrNomesEQUIPAS[grupo + 2][0] + arrDadosEQUIPAS[grupo + 2][7] + "º" + arrNomesEQUIPAS[grupo + 2][1]);
            grupo += 4;
        }
        out.close();
    }

    //Metodo para imprimir os resultados na formatação pedida;
    public static void ImprimirFormat(String[][] arrNomesEQUIPAS, int[][] arrDadosEQUIPAS, int qtdequipas) {
        System.out.printf("| Grp | Pos |");
        System.out.printf("%-17s", "Equipa");
        System.out.println("| Pts| J  | V  | E  | D  | GM | GS | GD |");
        System.out.println("|=====|=====|=================|====|====|====|====|====|====|====|====|");
        for (int i = 0; i < qtdequipas; i++) {
            System.out.printf("|%-5s|", arrNomesEQUIPAS[i][0]);
            System.out.printf("%5s|", arrDadosEQUIPAS[i][7]);
            System.out.printf("%-17s|", arrNomesEQUIPAS[i][1]);
            System.out.printf("%4s|", arrDadosEQUIPAS[i][6]);
            for (int p = 0; p < 6; p++) {
                System.out.printf("%4d|", arrDadosEQUIPAS[i][p]);
            }
            System.out.printf("%4d|", Math.abs(arrDadosEQUIPAS[i][4] - arrDadosEQUIPAS[i][5]));
            System.out.println("");
        }
    }
}
